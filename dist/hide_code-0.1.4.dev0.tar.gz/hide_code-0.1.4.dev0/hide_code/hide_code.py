import os
from os import path
import shutil
import jupyter_core.paths as j_path


def __main__():
	install()


def install(nb_path=None, DEBUG=False):
	print('Starting hide_code.js install')
	current_dir = path.abspath(path.dirname(__file__))
	config_dir = path.join(j_path.jupyter_config_path, 'custom')
	site_packages_path = os.__file__[:-6] + "site-packages"


	if path.isdir(config_dir):
		install_path = config_dir
	else:
		
		install_path = path.join(site_packages_path, "/notebook/static/custom")
	

	if nb_path != None:
		install_path = nb_path
		print("Using " + install_path)

	if DEBUG:
		print(install_path)

	# copy js into static/custom directory in Jupyter/iPython directory
	if(path.isdir(install_path)):
		shutil.copyfile(current_dir + "/hide_code.js", install_path + "/hide_code.js")
		print('Copying hide_code.js to ' + install_path) 

		# add require to end of custom.js to auto-load on notebook startup
		with open(install_path + "/custom.js", 'a') as customJS:
			with open(current_dir + "/auto-load.txt") as auto:
				customJS.write(auto.read())
				print("Configured custom.js to auto-load hide_code.js")
	else:
		print('Unable to install into ' + install_path)
		print('Directory doesn\'t exist.')
		print('Make sure Jupyter is installed.')